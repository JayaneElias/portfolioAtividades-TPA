/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Resp;
import java.util.Scanner;
/**
 *
 * @author FATEC ZONA LESTE
 */
public class Exercicio4 {
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        
        System.out.println("Informe a altura dos Degraus:");
        int alturaD=ler.nextInt();
        
        System.out.println("Informe a altura que ele quer alcançar subindo a escada:");
        int alturaA=ler.nextInt();
        
        int SubiuD=alturaA/alturaD;
        System.out.println("quantos degraus ele deverá subir?"+ SubiuD);
        
    }
    
}
