/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Resp;
import java.util.Scanner;
/**
 *
 * @author FATEC ZONA LESTE
 */
public class Exercicio01 {
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        
        System.out.println("Informe o tamanho da base maior do Trapézio:");
        int bma=ler.nextInt();
        
        System.out.println("Informe o tamanho da base menor do Trapézio:");
        int bmn=ler.nextInt();
        
        System.out.println("Informe a altura do Trapézio:");
        int alt=ler.nextInt();
        
        int área=((bma+bmn)*alt)/2;
        System.out.println("A Área do Trapézio é:"+área);
                
        
    }
    
}
