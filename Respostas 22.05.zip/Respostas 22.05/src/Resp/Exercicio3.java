/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Resp;
import java.util.Scanner;
/**
 *
 * @author FATEC ZONA LESTE
 */
public class Exercicio3 {
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        
      
        System.out.println("Digite seu nome:");
        String nome=ler.nextLine();
     
        System.out.println("Informe seu Salário:");
        double Salário=ler.nextDouble();
        
        System.out.println("O valor das Vendas:");
        double Vendas=ler.nextDouble();
        
        double Comissão=0.04*Vendas;
        System.out.println("Sua comissão em reais:"+Comissão);
        
        double  SalárioFinal=Salário+Comissão;
        System.out.println("Seu Salário Final é:"+SalárioFinal);
        
        
        
        
    }
    
}
