/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Resp;
import java.util.Scanner;
/**
 *
 * @author FATEC ZONA LESTE
 */
public class Exercicio5 {
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        
        System.out.println("Qual o custo do espataculo Teatral?");
        double CustoT=ler.nextDouble();
        
        System.out.println("O preço dos convites o para o Espetaculo?");
        double CustoC=ler.nextDouble();
        
        double Resultado=CustoT/CustoC;
        System.out.println("Foram vendidos um total de " + Resultado + " para o custo total do Espetaculo" );
        
    }
    
}
