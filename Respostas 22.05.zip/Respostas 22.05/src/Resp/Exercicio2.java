/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Resp;
import java.util.Scanner;
/**
 *
 * @author FATEC ZONA LESTE
 */
public class Exercicio2 {
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        
        System.out.println("Qual quantidade de dinheiro que você tem?");
        double  R=ler.nextDouble();
        
        double D=R*1.80;
        System.out.println("Qual será o valor se convertido para Dólar:"+D);
        
        double MA=R*2.00;
        System.out.println("Qual será o valor se convertido para Marco Alemão:"+MA);
        
        double LE=R*1.57;
        System.out.println("Qual será o valor se convertido para Libra Esterlina:"+LE);
        
    }
    
}
